const $ = id => document.getElementById(id);
const mean = a => a.reduce((s,x)=>s+x,0)/a.length;
const cap = x => Math.min(x,3);
const fmt = n => n>=1000 ? (n/1000).toFixed(1)+'k' : Math.round(n);
let heroes = null;

async function tfetch(url, ms=30000){
  const c = new AbortController();
  const t = setTimeout(()=>c.abort(), ms);
  try{ return await fetch(url,{signal:c.signal}); }
  catch(e){ if(e.name==='AbortError') throw new Error('TIMEOUT'); throw e; }
  finally{ clearTimeout(t); }
}

async function getHeroes(){
  if(heroes) return heroes;
  const r = await tfetch('https://api.opendota.com/api/heroes', 15000);
  heroes = Object.fromEntries((await r.json()).map(h=>[h.id,h.localized_name]));
  return heroes;
}

function analyze(m){
  const ps = m.players.map(p=>({...p, rad: p.player_slot<128}));
  ps.forEach(p=>['hero_damage','tower_damage','hero_healing','last_hits','gold_per_min','xp_per_min'].forEach(k=>{p[k]=p[k]||0;}));
  window.__hasDmg = ps.some(p=>p.hero_damage>0);
  const tk = {true:0,false:0};
  ps.forEach(p=>tk[p.rad]+=p.kills);
  ps.forEach(p=>{
    p.kda = (p.kills+p.assists)/Math.max(p.deaths,1);
    p.kp = (p.kills+p.assists)/Math.max(tk[p.rad],1);
  });
  const avg = k => mean(ps.map(p=>p[k])) || 1;
  const A = {kda:avg('kda'),kp:avg('kp'),gpm:avg('gold_per_min'),dmg:avg('hero_damage'),xpm:avg('xp_per_min'),d:avg('deaths')};
  ps.forEach(p=>{
    p.score = 0.30*cap(p.kda/A.kda) + 0.25*cap(p.kp/A.kp) + 0.20*cap(p.gold_per_min/A.gpm)
            + 0.15*(window.__hasDmg ? cap(p.hero_damage/A.dmg) : cap(p.xp_per_min/A.xpm)) + 0.10*cap(A.d/Math.max(p.deaths,1));
  });
  return ps;
}

function tags(p, all){
  const t = [];
  const by = (k,f=Math.max) => f(...all.map(x=>x[k]));
  const sorted = [...all].sort((a,b)=>b.score-a.score);
  if(p===sorted[0]) t.push(['MVP матча','gold']);
  if(p===sorted[9]) t.push(['Хуже всех','bad']);
  if(p.score>=1.2 && p!==sorted[0]) t.push(['Выше нормы','good']);
  if(p.score<=0.8 && p!==sorted[9]) t.push(['Ниже нормы','bad']);
  if(p.leaver_status>1) t.push(['Ливнул','bad']);
  if(p.deaths===by('deaths') && p.deaths>=8) t.push(['Больше всех умер','bad']);
  if(p.kills===by('kills')) t.push(['Больше всех убийств','good']);
  if(window.__hasDmg && p.hero_damage===by('hero_damage')) t.push(['Макс. урон по героям','good']);
  if(p.tower_damage===by('tower_damage') && p.tower_damage>0) t.push(['Снёс больше всех башен','good']);
  if(p.hero_healing===by('hero_healing') && p.hero_healing>1000) t.push(['Лучший хил','good']);
  if(p.deaths>=10 && p.kills+p.assists<p.deaths) t.push(['Кормил врага','bad']);
  return t;
}

function card(p, H){
  const name = p.personaname || 'Аноним';
  const tg = tags(p, window.__ps).map(([x,c])=>`<span class="tag ${c}">${x}</span>`).join('');
  return `<div class="p">
    <div class="top"><div class="name">${H[p.hero_id]||'Герой'} <span>${name.replace(/</g,'&lt;')}</span></div>
    <div class="score">Рейтинг ${p.score.toFixed(2)}</div></div>
    <div class="stats"><span>K/D/A <b>${p.kills}/${p.deaths}/${p.assists}</b></span>
    <span>GPM <b>${p.gold_per_min}</b></span><span>XPM <b>${p.xp_per_min}</b></span>
    <span>Добито <b>${p.last_hits}</b></span>${window.__hasDmg?`<span>Урон <b>${fmt(p.hero_damage)}</b></span>
    <span>Башни <b>${fmt(p.tower_damage)}</b></span><span>Хил <b>${fmt(p.hero_healing)}</b></span>`:''}</div>
    <div class="tags">${tg}</div></div>`;
}

function award(title, p, val, H){
  return `<div class="aw"><small>${title}</small><b>${H[p.hero_id]||'Герой'}</b> — ${val}</div>`;
}

async function run(){
  const id = $('mid').value.trim();
  if(!/^\d{6,12}$/.test(id)){ $('msg').textContent='ID матча — это число, например 7890123456.'; return; }
  $('msg').textContent='Загружаю матч…'; $('out').innerHTML='';
  try{
    const H = await getHeroes();
    $('msg').textContent='Героев загрузил, тяну данные матча (может занять до 30 секунд)…';
    let r;
    try{ r = await tfetch('https://api.opendota.com/api/matches/'+id); }
    catch(e){ if(e.message!=='TIMEOUT') throw e; $('msg').textContent='OpenDota отвечает медленно, пробую ещё раз…'; r = await tfetch('https://api.opendota.com/api/matches/'+id); }
    if(r.status===429) throw new Error('OpenDota просит подождать (лимит запросов). Повтори через минуту.');
    if(r.status===404) throw new Error('Матч не найден. Проверь ID.');
    if(!r.ok) throw new Error('OpenDota ответил ошибкой '+r.status+'. Попробуй позже.');
    const m = await r.json();
    if(!m.players || m.players[0].kills===undefined) throw new Error('Матч ещё не обработан. Подожди пару минут и повтори.');
    const ps = analyze(m); window.__ps = ps;
    const best = [...ps].sort((a,b)=>b.score-a.score)[0];
    const worst = [...ps].sort((a,b)=>a.score-b.score)[0];
    const mx = k => ps.reduce((a,b)=>b[k]>a[k]?b:a);
    const dur = Math.floor(m.duration/60)+':'+String(m.duration%60).padStart(2,'0');
    const rw = m.radiant_win;
    const team = (rad,title,cls)=>`<section class="team ${cls}"><h2>${title}</h2>${ps.filter(p=>p.rad===rad).sort((a,b)=>b.score-a.score).map(p=>card(p,H)).join('')}</section>`;
    $('out').innerHTML = `
      <div class="head"><b class="${rw?'win-r':'win-d'}">Победа: ${rw?'Силы Света':'Силы Тьмы'}</b>
      <span>Счёт ${ps.filter(p=>p.rad).reduce((a,p)=>a+p.kills,0)}:${ps.filter(p=>!p.rad).reduce((a,p)=>a+p.kills,0)}</span><span>Время ${dur}</span><span>Матч ${id}</span></div>
      <div class="awards">
        ${award('Лучший игрок',best,'рейтинг '+best.score.toFixed(2),H)}
        ${award('Хуже всех',worst,'рейтинг '+worst.score.toFixed(2),H)}
        ${award('Больше всех умер',mx('deaths'),mx('deaths').deaths+' смертей',H)}
        ${window.__hasDmg?award('Больше всего урона',mx('hero_damage'),fmt(mx('hero_damage').hero_damage),H):award('Больше всех убийств',mx('kills'),mx('kills').kills+' убийств',H)}
      </div>
      ${team(true,'Силы Света','r')}${team(false,'Силы Тьмы','d')}
      <p class="sub" style="margin-top:20px">Рейтинг считается относительно среднего по матчу: K/D/A, участие в убийствах, GPM, урон и смерти. Саппорты оцениваются мягче по золоту благодаря участию в убийствах, но это оценка, а не истина.</p>`;
    $('msg').textContent='';
  }catch(e){
    $('msg').textContent = e.message==='TIMEOUT' ? 'OpenDota не ответил за 30 секунд. Попробуй другой матч или повтори позже.'
      : e.message.includes('Failed to fetch') ? 'Запрос к OpenDota заблокирован. Отключи блокировщик рекламы/VPN для этой страницы и повтори.' : e.message;
  }
}
$('go').onclick = run;
$('mid').addEventListener('keydown',e=>{ if(e.key==='Enter') run(); });